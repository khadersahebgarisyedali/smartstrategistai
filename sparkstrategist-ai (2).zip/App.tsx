
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Dashboard from './views/Dashboard';
import StartupAdvisor from './views/StartupAdvisor';
import ContentGenerator from './views/ContentGenerator';
import ImageLab from './views/ImageLab';
import Support from './views/Support';
import Auth from './views/Auth';
import PropertyHub from './views/PropertyHub';
import Profile from './views/Profile';
import { ViewType } from './types';
import { supabase } from './services/supabase';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<ViewType>(ViewType.DASHBOARD);
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-500 font-medium">Loading SparkStrategist...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return <Auth />;
  }

  const renderView = () => {
    switch (activeView) {
      case ViewType.DASHBOARD:
        return <Dashboard onNavigate={setActiveView} />;
      case ViewType.ADVISOR:
        return <StartupAdvisor />;
      case ViewType.MARKETING:
        return <ContentGenerator />;
      case ViewType.IMAGE_LAB:
        return <ImageLab />;
      case ViewType.SUPPORT:
        return <Support userEmail={session.user.email} />;
      case ViewType.PROPERTIES:
        return <PropertyHub />;
      case ViewType.PROFILE:
        return <Profile user={session.user} />;
      default:
        return <Dashboard onNavigate={setActiveView} />;
    }
  };

  return (
    <Layout activeView={activeView} onViewChange={setActiveView} user={session.user}>
      {renderView()}
    </Layout>
  );
};

export default App;
