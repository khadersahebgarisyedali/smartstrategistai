
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";

const getApiKey = () => {
  try {
    return (process.env.API_KEY) || '';
  } catch {
    return '';
  }
};

const createAI = () => new GoogleGenAI({ apiKey: getApiKey() });

export const generatePropertyDescription = async (details: string): Promise<string> => {
  const ai = createAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a compelling, professional real estate description for a property with these details: ${details}. Highlight its best features and use an inviting tone.`,
    });
    return response.text || "No description generated.";
  } catch (error: any) {
    throw new Error(error.message || "Failed to generate property description.");
  }
};

export const getStartupStrategy = async (problem: string): Promise<string> => {
  const ai = createAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Act as a Silicon Valley startup advisor. Analyze this real-world problem deeply: [${problem}]. 
      Provide: Root cause analysis, Market size estimation, Competitive landscape, Unique value proposition, 
      AI integration strategy, Technical architecture suggestion, MVP roadmap (30-day plan), Revenue model, 
      Risk analysis, and a Pitch-ready summary. Make it investor-level detailed.`,
      config: {
        thinkingConfig: { thinkingBudget: 32768 }
      }
    });
    return response.text || "No strategy generated.";
  } catch (error: any) {
    throw new Error(error.message || "Startup strategy generation failed.");
  }
};

export const generateMarketingContent = async (topic: string, format: string): Promise<string> => {
  const ai = createAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate high-quality marketing content for a small business on the topic: "${topic}". 
      The format should be a ${format}. Focus on being catchy, professional, and results-driven.`,
    });
    return response.text || "No content generated.";
  } catch (error: any) {
    throw new Error(error.message || "Marketing content generation failed.");
  }
};

export const editImageWithNanoBanana = async (
  base64Image: string,
  mimeType: string,
  prompt: string
): Promise<string | null> => {
  const ai = createAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          { text: `Modify this image: ${prompt}. Return ONLY the edited image data as an inline part.` },
        ],
      },
      config: {
        systemInstruction: "You are an AI image editor. Output the modified version of the image provided. Do not use text if you can provide an image.",
      }
    });

    const imagePart = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
    if (imagePart?.inlineData) {
      return `data:image/png;base64,${imagePart.inlineData.data}`;
    }
    
    const textPart = response.candidates?.[0]?.content?.parts?.find(p => p.text);
    if (textPart) {
      throw new Error(`AI returned text instead of image: ${textPart.text.substring(0, 100)}...`);
    }
    
    return null;
  } catch (error: any) {
    throw error;
  }
};
