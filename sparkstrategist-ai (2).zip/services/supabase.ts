
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://mefutwevlcrbzyleksjd.supabase.co';
const supabaseAnonKey = 'sb_publishable_XUoygD8JNLU7AVxJYPQiMg_0jJEXMyg';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const saveStrategy = async (problem: string, strategy: string) => {
  const { data, error } = await supabase
    .from('strategies')
    .insert([{ problem, content: strategy }])
    .select();
  if (error) throw error;
  return data;
};

export const saveMarketingContent = async (topic: string, format: string, content: string) => {
  const { data, error } = await supabase
    .from('marketing_content')
    .insert([{ topic, format, content }])
    .select();
  if (error) throw error;
  return data;
};

export const saveInquiry = async (name: string, email: string, subject: string, message: string) => {
  const { data, error } = await supabase
    .from('inquiries')
    .insert([{ name, email, subject, message }])
    .select();
  if (error) throw error;
  return data;
};

// Property Services
export const listProperty = async (property: { title: string, description: string, price: string, location: string, image_url: string }) => {
  const { data, error } = await supabase
    .from('properties')
    .insert([property])
    .select();
  if (error) throw error;
  return data;
};

export const getProperties = async () => {
  const { data, error } = await supabase
    .from('properties')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data || [];
};

export const toggleSaveProperty = async (propertyId: string, isSaved: boolean) => {
  if (isSaved) {
    const { error } = await supabase
      .from('saved_properties')
      .delete()
      .match({ property_id: propertyId });
    if (error) throw error;
  } else {
    const { error } = await supabase
      .from('saved_properties')
      .insert([{ property_id: propertyId }]);
    if (error) throw error;
  }
};

export const getSavedPropertyIds = async () => {
  const { data, error } = await supabase
    .from('saved_properties')
    .select('property_id');
  if (error) throw error;
  return data.map(item => item.property_id);
};

export const getUserListings = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];
  const { data, error } = await supabase
    .from('properties')
    .select('*')
    .eq('user_id', user.id);
  if (error) throw error;
  return data || [];
};

export const getUserSavedProperties = async () => {
  const { data, error } = await supabase
    .from('saved_properties')
    .select('*, properties(*)');
  if (error) throw error;
  return data?.map(item => item.properties) || [];
};

export const getRecentActivity = async () => {
  const { data: strategies } = await supabase
    .from('strategies')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(3);
    
  const { data: marketing } = await supabase
    .from('marketing_content')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(3);

  return { strategies: strategies || [], marketing: marketing || [] };
};

export const signOut = () => supabase.auth.signOut();
