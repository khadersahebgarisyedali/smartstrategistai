
import React, { useState, useEffect } from 'react';
import { ViewType } from '../types';
import { signOut } from '../services/supabase';

interface LayoutProps {
  children: React.ReactNode;
  activeView: ViewType;
  onViewChange: (view: ViewType) => void;
  user?: any;
}

const Layout: React.FC<LayoutProps> = ({ children, activeView, onViewChange, user }) => {
  const [isApiConnected, setIsApiConnected] = useState<boolean | null>(null);

  useEffect(() => {
    const checkKey = () => {
      try {
        const hasKey = !!(process.env.API_KEY);
        setIsApiConnected(hasKey);
      } catch {
        setIsApiConnected(false);
      }
    };
    checkKey();
    const interval = setInterval(checkKey, 5000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    { id: ViewType.DASHBOARD, label: 'Dashboard', icon: '📊' },
    { id: ViewType.PROPERTIES, label: 'Property Hub', icon: '🏠' },
    { id: ViewType.ADVISOR, label: 'Startup Advisor', icon: '💡' },
    { id: ViewType.MARKETING, label: 'Marketing Kit', icon: '📣' },
    { id: ViewType.IMAGE_LAB, label: 'Image Lab', icon: '🎨' },
    { id: ViewType.PROFILE, label: 'My Profile', icon: '👤' },
    { id: ViewType.SUPPORT, label: 'Help & Support', icon: '🤝' },
  ];

  const handleSignOut = async () => {
    await signOut();
  };

  const openKeySelector = async () => {
    if ((window as any).aistudio) {
      await (window as any).aistudio.openSelectKey();
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 hidden md:flex flex-col">
        <div className="p-6">
          <h1 className="text-xl font-bold text-indigo-600 flex items-center gap-2">
            <span className="text-2xl">✨</span> SparkStrategist
          </h1>
        </div>
        <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-all ${
                activeView === item.id
                  ? 'bg-indigo-50 text-indigo-700 shadow-sm'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-100">
          <div className="bg-indigo-600 text-white rounded-xl p-4 mb-4 relative overflow-hidden">
            <div className="relative z-10">
              <p className="text-xs font-semibold uppercase tracking-wider opacity-80">API Status</p>
              <div className="flex items-center gap-2 mt-1">
                <div className={`w-2 h-2 rounded-full ${isApiConnected ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`}></div>
                <p className="text-sm font-bold">{isApiConnected ? 'Connected' : 'Disconnected'}</p>
              </div>
              {!isApiConnected && (
                <button 
                  onClick={openKeySelector}
                  className="text-[10px] mt-2 bg-white/20 hover:bg-white/30 px-2 py-1 rounded font-bold uppercase"
                >
                  Fix Connection
                </button>
              )}
            </div>
            <div className="absolute top-0 right-0 w-16 h-16 bg-white/10 rounded-full -mr-8 -mt-8"></div>
          </div>
          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors font-medium"
          >
            <span>🚪</span> Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 z-10">
          <h2 className="text-lg font-semibold text-slate-800 capitalize">
            {activeView.replace('_', ' ')}
          </h2>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-xs font-bold text-slate-400 uppercase">Current Account</p>
              <p className="text-sm text-slate-600 truncate max-w-[150px]">{user?.email}</p>
            </div>
            <button 
              onClick={() => onViewChange(ViewType.PROFILE)}
              className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-white font-bold text-xs uppercase shadow-inner shadow-black/10 hover:ring-4 hover:ring-indigo-100 transition-all cursor-pointer"
            >
              {user?.email?.charAt(0) || 'U'}
            </button>
          </div>
        </header>

        {/* View Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </div>
      </main>

      {/* Mobile Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex justify-around p-2 z-50 overflow-x-auto">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={`flex flex-col items-center gap-1 p-2 min-w-[60px] ${
              activeView === item.id ? 'text-indigo-600' : 'text-slate-400'
            }`}
          >
            <span className="text-xl">{item.icon}</span>
            <span className="text-[10px] font-medium">{item.label.split(' ')[0]}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

export default Layout;
