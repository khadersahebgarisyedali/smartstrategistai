
import React, { useState, useRef, useEffect } from 'react';
import { editImageWithNanoBanana } from '../services/gemini';

// Fix: Accessing pre-defined aistudio via window casting to avoid global declaration conflicts
const getAiStudio = () => (window as any).aistudio;

const ImageLab: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [needsKey, setNeedsKey] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    checkKeyStatus();
  }, []);

  const checkKeyStatus = async () => {
    // Fix: Using casting to access global aistudio safely
    const aistudio = getAiStudio();
    if (aistudio) {
      const hasKey = await aistudio.hasSelectedApiKey();
      setNeedsKey(!hasKey);
    }
  };

  const handleOpenKeySelector = async () => {
    // Fix: Using casting to access global aistudio safely
    const aistudio = getAiStudio();
    if (aistudio) {
      await aistudio.openSelectKey();
      // Assume success after triggering to mitigate race condition
      setNeedsKey(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Basic size check (approx 4MB)
      if (file.size > 4 * 1024 * 1024) {
        alert("Image is too large. Please select an image under 4MB for faster processing.");
        return;
      }
      setMimeType(file.type);
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(',')[1];
        setImage(base64);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProcess = async () => {
    if (!image || !prompt) return;
    setLoading(true);
    try {
      const edited = await editImageWithNanoBanana(image, mimeType, prompt);
      if (edited) {
        setResult(edited);
      } else {
        alert('The AI model did not return a modified image. Try a more specific prompt.');
      }
    } catch (err: any) {
      console.error("Image Lab Error:", err);
      
      const errorMessage = err.message || "Unknown error";
      
      // Fix: Reset key selection state if API key is invalid or not found
      if (errorMessage.includes("Requested entity was not found") || errorMessage.includes("API_KEY")) {
        setNeedsKey(true);
        alert("To use Image Lab features, you must select a valid API key from a paid GCP project.");
      } else {
        alert(`AI Error: ${errorMessage}`);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!result) return;
    const link = document.createElement('a');
    link.href = result;
    link.download = `spark-edit-${Date.now()}.png`;
    link.click();
  };

  const handleReset = () => {
    setImage(null);
    setMimeType('');
    setPrompt('');
    setResult(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      {needsKey && (
        <div className="bg-amber-50 border border-amber-200 p-6 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <span className="text-3xl">🔑</span>
            <div>
              <h4 className="font-bold text-amber-800">API Key Required for Image Editing</h4>
              <p className="text-sm text-amber-700">Image generation models require a selected API key from a paid project.</p>
              <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-xs font-bold underline text-amber-900">Learn about billing</a>
            </div>
          </div>
          <button 
            onClick={handleOpenKeySelector}
            className="px-6 py-2 bg-amber-600 text-white rounded-xl font-bold hover:bg-amber-700 transition-colors shrink-0"
          >
            Select API Key
          </button>
        </div>
      )}

      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
        <div className="mb-8 text-center flex justify-between items-center">
          <div className="text-left">
            <h3 className="text-2xl font-bold text-slate-800 mb-2">Nano-Banana Image Lab</h3>
            <p className="text-slate-500">Edit visual assets using natural language.</p>
          </div>
          <button 
            onClick={handleReset}
            className="text-sm font-bold text-slate-400 hover:text-slate-600 transition-colors"
          >
            Clear All
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
          <div className="space-y-6">
            <div 
              onClick={() => !loading && fileInputRef.current?.click()}
              className={`aspect-square rounded-2xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all overflow-hidden ${
                image ? 'border-indigo-400 bg-indigo-50' : 'border-slate-300 hover:border-indigo-400 hover:bg-slate-50'
              } ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {image ? (
                <img 
                  src={`data:${mimeType};base64,${image}`} 
                  alt="Source" 
                  className="w-full h-full object-cover" 
                />
              ) : (
                <>
                  <span className="text-4xl mb-4">📸</span>
                  <span className="text-sm font-medium text-slate-500">Click to upload photo</span>
                </>
              )}
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept="image/*" 
                disabled={loading}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">What changes should I make?</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., 'Make the sky sunset orange' or 'Add a modern laptop to the desk'"
                className="w-full p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 shadow-sm resize-none h-24"
                disabled={loading}
              />
            </div>

            <button
              onClick={handleProcess}
              disabled={loading || !image || !prompt}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-100"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  AI is Editing...
                </>
              ) : '✨ Magic Edit'}
            </button>
          </div>

          <div className="space-y-4">
            <div className="aspect-square bg-slate-100 rounded-2xl flex flex-col items-center justify-center border border-slate-200 overflow-hidden relative group">
              {result ? (
                <>
                  <img src={result} alt="Edited Result" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                    <button 
                      onClick={handleDownload}
                      className="bg-white text-slate-800 px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 hover:bg-slate-50"
                    >
                      <span>📥</span> Download
                    </button>
                  </div>
                </>
              ) : (
                <div className="text-center px-6">
                  <span className="text-4xl block mb-4">🎨</span>
                  <p className="text-sm text-slate-400">Edited result will appear here.</p>
                </div>
              )}
              {loading && (
                <div className="absolute inset-0 bg-white/70 backdrop-blur-md flex items-center justify-center z-10">
                  <div className="text-center">
                    <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="font-bold text-indigo-700 animate-pulse">Processing Pixels...</p>
                  </div>
                </div>
              )}
            </div>
            {result && (
              <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-xl text-xs text-indigo-700 leading-relaxed">
                <strong>Model:</strong> Gemini 2.5 Flash Image<br/>
                <strong>Status:</strong> Generation Complete.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageLab;
