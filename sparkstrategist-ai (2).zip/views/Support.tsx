
import React, { useState } from 'react';
import { saveInquiry } from '../services/supabase';

const Support: React.FC<{ userEmail?: string }> = ({ userEmail }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: userEmail || '',
    subject: '',
    message: ''
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await saveInquiry(formData.name, formData.email, formData.subject, formData.message);
      setSuccess(true);
      setFormData({ name: '', email: userEmail || '', subject: '', message: '' });
    } catch (err) {
      console.error(err);
      alert('Error sending inquiry. Make sure the "inquiries" table exists in your database.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto animate-fadeIn">
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
        <h3 className="text-2xl font-bold text-slate-800 mb-2">Inquiry Form</h3>
        <p className="text-slate-500 mb-8">Need custom strategy help or found a bug? Send us a message and it will be stored in our database.</p>

        {success ? (
          <div className="bg-green-50 border border-green-200 text-green-700 p-6 rounded-2xl text-center">
            <div className="text-4xl mb-4">✅</div>
            <h4 className="text-lg font-bold">Inquiry Submitted!</h4>
            <p className="mt-2">We have received your message and stored it in your workspace database.</p>
            <button 
              onClick={() => setSuccess(false)}
              className="mt-6 px-6 py-2 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-colors"
            >
              Send Another
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Your Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="john@example.com"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1">Subject</label>
              <input
                type="text"
                required
                value={formData.subject}
                onChange={(e) => setFormData({...formData, subject: e.target.value})}
                className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                placeholder="How can we help?"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1">Message</label>
              <textarea
                required
                rows={5}
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                placeholder="Tell us more details..."
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-100 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Saving Inquiry...
                </>
              ) : 'Submit Inquiry'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default Support;
