
import React, { useEffect, useState } from 'react';
import { ViewType } from '../types';
import { getRecentActivity } from '../services/supabase';

interface DashboardProps {
  onNavigate: (view: ViewType) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const [activity, setActivity] = useState<{strategies: any[], marketing: any[]}>({strategies: [], marketing: []});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchActivity = async () => {
      try {
        const data = await getRecentActivity();
        setActivity(data);
      } catch (err) {
        console.warn('Supabase activity fetch failed. Table may not be ready.', err);
      } finally {
        setLoading(false);
      }
    };
    fetchActivity();
  }, []);

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="bg-indigo-700 rounded-3xl p-8 text-white shadow-xl overflow-hidden relative">
        <div className="relative z-10">
          <h2 className="text-3xl font-bold mb-4">Grow your business with Spark AI</h2>
          <p className="text-indigo-100 max-w-xl text-lg mb-8">
            Access world-class strategy, high-converting marketing content, and instant visual editing tools. Now connected to your <b>Supabase</b> workspace.
          </p>
          <div className="flex flex-wrap gap-4">
            <button 
              onClick={() => onNavigate(ViewType.ADVISOR)}
              className="px-6 py-3 bg-white text-indigo-700 rounded-xl font-bold hover:bg-indigo-50 transition-colors"
            >
              Get a Strategy
            </button>
            <button 
              onClick={() => onNavigate(ViewType.MARKETING)}
              className="px-6 py-3 bg-indigo-500 text-white border border-indigo-400 rounded-xl font-bold hover:bg-indigo-400 transition-colors"
            >
              Create Marketing Content
            </button>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600 rounded-full blur-3xl -mr-20 -mt-20 opacity-50"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center text-2xl mb-4">💡</div>
          <h3 className="font-bold text-slate-800 mb-2">Startup Advisor</h3>
          <p className="text-sm text-slate-500 mb-4">Deep dive into market analysis and business roadmaps using Gemini 3 Pro reasoning.</p>
          <button onClick={() => onNavigate(ViewType.ADVISOR)} className="text-indigo-600 font-semibold text-sm hover:underline">Launch Advisor →</button>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-2xl mb-4">📣</div>
          <h3 className="font-bold text-slate-800 mb-2">Marketing Content</h3>
          <p className="text-sm text-slate-500 mb-4">Generate ads, social posts, and email campaigns in seconds with high-speed models.</p>
          <button onClick={() => onNavigate(ViewType.MARKETING)} className="text-indigo-600 font-semibold text-sm hover:underline">Open Kit →</button>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center text-2xl mb-4">🎨</div>
          <h3 className="font-bold text-slate-800 mb-2">Nano-Banana Lab</h3>
          <p className="text-sm text-slate-500 mb-4">Edit product photos and marketing assets using text prompts and Gemini 2.5 Flash Image.</p>
          <button onClick={() => onNavigate(ViewType.IMAGE_LAB)} className="text-indigo-600 font-semibold text-sm hover:underline">Enter Lab →</button>
        </div>
      </div>

      {/* Recent Activity from Supabase */}
      <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <span className="w-8 h-8 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center text-sm">📁</span>
            Recent Supabase Workspace Activity
          </h3>
          <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">Live Sync</div>
        </div>
        
        {loading ? (
          <div className="flex items-center gap-2 text-slate-400 italic">
            <div className="w-4 h-4 border-2 border-slate-200 border-t-indigo-500 rounded-full animate-spin"></div>
            Connecting to your database...
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Latest Strategies</h4>
              <div className="space-y-3">
                {activity.strategies.length > 0 ? activity.strategies.map((s: any) => (
                  <div key={s.id} className="p-4 bg-slate-50 rounded-xl border border-slate-100 hover:border-indigo-200 transition-colors">
                    <p className="text-sm font-bold text-slate-800 truncate">{s.problem}</p>
                    <p className="text-xs text-slate-500 mt-1">Generated {new Date(s.created_at).toLocaleDateString()}</p>
                  </div>
                )) : (
                  <p className="text-sm text-slate-400 italic">No strategies saved yet.</p>
                )}
              </div>
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Latest Marketing Content</h4>
              <div className="space-y-3">
                {activity.marketing.length > 0 ? activity.marketing.map((m: any) => (
                  <div key={m.id} className="p-4 bg-slate-50 rounded-xl border border-slate-100 hover:border-indigo-200 transition-colors">
                    <p className="text-sm font-bold text-slate-800 truncate">[{m.format}] {m.topic}</p>
                    <p className="text-xs text-slate-500 mt-1">Saved {new Date(m.created_at).toLocaleDateString()}</p>
                  </div>
                )) : (
                  <p className="text-sm text-slate-400 italic">No marketing content saved yet.</p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
