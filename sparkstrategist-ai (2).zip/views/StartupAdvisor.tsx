
import React, { useState } from 'react';
import { getStartupStrategy } from '../services/gemini';
import { saveStrategy } from '../services/supabase';

const StartupAdvisor: React.FC = () => {
  const [problem, setProblem] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!problem.trim()) return;
    setLoading(true);
    setResult('');
    setSaved(false);
    try {
      const response = await getStartupStrategy(problem);
      setResult(response);
    } catch (err) {
      console.error(err);
      setResult('Error generating strategy. Please check your API key and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!result || !problem) return;
    setSaving(true);
    try {
      await saveStrategy(problem, result);
      setSaved(true);
    } catch (err) {
      console.error(err);
      alert('Failed to save to Supabase. Ensure your table "strategies" exists with columns: problem, content.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
        <h3 className="text-xl font-bold text-slate-800 mb-2">Deep Strategy Analysis</h3>
        <p className="text-slate-500 text-sm mb-6">Describe your business problem or idea. Gemini 3 Pro will analyze the market, competitors, and provide an MVP roadmap.</p>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <textarea
            value={problem}
            onChange={(e) => setProblem(e.target.value)}
            placeholder="e.g., Small farmers struggle to find direct-to-consumer buyers..."
            className="w-full h-32 p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
          />
          <button
            type="submit"
            disabled={loading || !problem.trim()}
            className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-200"
          >
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                Analyzing Deeply...
              </>
            ) : 'Generate Silicon Valley Grade Strategy'}
          </button>
        </form>
      </div>

      {result && (
        <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm prose prose-slate max-w-none relative">
          <div className="absolute top-6 right-8 flex gap-2">
             <button
              onClick={handleSave}
              disabled={saving || saved}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                saved ? 'bg-green-100 text-green-700' : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
              }`}
            >
              {saving ? 'Saving...' : saved ? '✓ Saved to Workspace' : '💾 Save to Supabase'}
            </button>
          </div>
          <div className="whitespace-pre-wrap text-slate-700 font-light leading-relaxed mt-12">
            {result}
          </div>
        </div>
      )}
    </div>
  );
};

export default StartupAdvisor;
