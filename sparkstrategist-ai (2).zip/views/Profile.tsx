
import React, { useState, useEffect } from 'react';
import { getUserListings, getUserSavedProperties } from '../services/supabase';
import { Property } from '../types';

const Profile: React.FC<{ user: any }> = ({ user }) => {
  const [listings, setListings] = useState<Property[]>([]);
  const [saved, setSaved] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'listings' | 'saved'>('listings');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [myListings, mySaved] = await Promise.all([getUserListings(), getUserSavedProperties()]);
        setListings(myListings);
        setSaved(mySaved);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="animate-fadeIn space-y-8">
      {/* Header */}
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm flex flex-col md:flex-row items-center gap-6">
        <div className="w-24 h-24 bg-indigo-600 rounded-full flex items-center justify-center text-white text-4xl font-bold shadow-xl shadow-indigo-100">
          {user?.email?.charAt(0).toUpperCase()}
        </div>
        <div className="text-center md:text-left">
          <h2 className="text-2xl font-bold text-slate-800">{user?.email}</h2>
          <p className="text-slate-500">Spark AI Member since {new Date(user?.created_at).toLocaleDateString()}</p>
          <div className="flex gap-4 mt-4 justify-center md:justify-start">
            <div className="text-center bg-slate-50 px-4 py-2 rounded-xl">
              <span className="block text-lg font-bold text-indigo-600">{listings.length}</span>
              <span className="text-xs text-slate-500 uppercase font-bold">Listings</span>
            </div>
            <div className="text-center bg-slate-50 px-4 py-2 rounded-xl">
              <span className="block text-lg font-bold text-pink-500">{saved.length}</span>
              <span className="text-xs text-slate-500 uppercase font-bold">Saved</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-slate-100 rounded-2xl w-fit">
        <button 
          onClick={() => setActiveTab('listings')}
          className={`px-6 py-2 rounded-xl font-bold text-sm transition-all ${activeTab === 'listings' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
        >
          My Listings
        </button>
        <button 
          onClick={() => setActiveTab('saved')}
          className={`px-6 py-2 rounded-xl font-bold text-sm transition-all ${activeTab === 'saved' ? 'bg-white text-pink-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
        >
          Liked Properties
        </button>
      </div>

      {/* Content */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full text-center py-20 text-slate-400">Loading properties...</div>
        ) : (
          (activeTab === 'listings' ? listings : saved).length > 0 ? (
            (activeTab === 'listings' ? listings : saved).map(item => (
              <div key={item.id} className="bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm">
                <div className="aspect-video bg-slate-200">
                  {item.image_url ? (
                    <img src={item.image_url} alt={item.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-4xl">🏙️</div>
                  )}
                </div>
                <div className="p-4">
                  <h4 className="font-bold text-slate-800 truncate">{item.title}</h4>
                  <p className="text-xs text-slate-400 mb-2">{item.location}</p>
                  <p className="text-indigo-600 font-bold text-sm">{item.price}</p>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full py-20 text-center bg-white rounded-3xl border border-dashed border-slate-300">
              <p className="text-slate-400 font-medium">No properties found in this section.</p>
            </div>
          )
        )}
      </div>
    </div>
  );
};

export default Profile;
