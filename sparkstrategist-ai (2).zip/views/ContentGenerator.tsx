
import React, { useState } from 'react';
import { generateMarketingContent } from '../services/gemini';
import { saveMarketingContent } from '../services/supabase';

const ContentGenerator: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [format, setFormat] = useState('Instagram Caption');
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const formats = [
    'Instagram Caption',
    'Facebook Ad Copy',
    'LinkedIn Thought Leadership Post',
    'Cold Outreach Email',
    'Newsletter Weekly Blast',
    'Product Description',
    'Landing Page Headline & Hero'
  ];

  const handleGenerate = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setContent('');
    setSaved(false);
    setError(null);
    try {
      const res = await generateMarketingContent(topic, format);
      setContent(res);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error generating content.');
      if (err.message?.includes('Found') || err.message?.includes('API_KEY')) {
        setError("API Key not found or invalid. Please check the sidebar status.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!content || !topic) return;
    setSaving(true);
    try {
      await saveMarketingContent(topic, format, content);
      setSaved(true);
    } catch (err) {
      console.error(err);
      alert('Failed to save to Supabase. Ensure your table "marketing_content" exists.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fadeIn">
      <div className="space-y-6">
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
          <h3 className="text-xl font-bold text-slate-800 mb-4">Content Builder</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">What are you selling/sharing?</label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., Organic handmade soap for sensitive skin"
                className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Content Format</label>
              <select
                value={format}
                onChange={(e) => setFormat(e.target.value)}
                className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500"
              >
                {formats.map(f => <option key={f} value={f}>{f}</option>)}
              </select>
            </div>
            <button
              onClick={handleGenerate}
              disabled={loading || !topic.trim()}
              className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-lg shadow-indigo-100"
            >
              {loading ? (
                <div className="flex items-center justify-center gap-2">
                   <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                   AI is Writing...
                </div>
              ) : 'Generate Content'}
            </button>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-100 p-4 rounded-xl text-red-600 text-sm font-medium animate-fadeIn">
            ⚠️ {error}
          </div>
        )}

        <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-2xl">
          <h4 className="font-bold text-indigo-900 mb-2 flex items-center gap-2">
            <span>✨</span> Pro Tip
          </h4>
          <p className="text-sm text-indigo-700 leading-relaxed">
            The more specific your input, the better the result. Save your best variants to your Supabase workspace.
          </p>
        </div>
      </div>

      <div className="bg-slate-900 rounded-3xl p-8 text-slate-300 min-h-[400px] shadow-2xl relative overflow-hidden flex flex-col border border-slate-800">
        <div className="absolute top-0 right-0 p-4 flex gap-2 z-10">
           <button 
            onClick={handleSave}
            disabled={saving || saved || !content}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
              saved ? 'bg-green-600 text-white' : 'bg-slate-700 hover:bg-slate-600 text-slate-300'
            }`}
          >
            {saving ? 'Saving...' : saved ? 'Saved' : 'Save to DB'}
          </button>
          <button 
            onClick={() => navigator.clipboard.writeText(content)}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-xs font-bold uppercase tracking-wider"
          >
            Copy
          </button>
        </div>
        <div className="flex-1 whitespace-pre-wrap font-mono text-sm leading-relaxed overflow-y-auto mt-8">
          {loading ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-500">
              <div className="w-12 h-12 border-4 border-slate-700 border-t-indigo-500 rounded-full animate-spin mb-4"></div>
              <p className="animate-pulse">Gemini 3 Flash is thinking...</p>
            </div>
          ) : content ? (
            <div className="animate-fadeIn">{content}</div>
          ) : (
            <div className="h-full flex items-center justify-center opacity-30 italic">
              Result will appear here...
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ContentGenerator;
