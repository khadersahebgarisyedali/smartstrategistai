
import React, { useState, useEffect } from 'react';
import { listProperty, getProperties, toggleSaveProperty, getSavedPropertyIds } from '../services/supabase';
import { generatePropertyDescription } from '../services/gemini';
import { Property } from '../types';

const PropertyHub: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [savedIds, setSavedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    location: '',
    price: '',
    description: '',
    image_url: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [props, saved] = await Promise.all([getProperties(), getSavedPropertyIds()]);
      setProperties(props);
      setSavedIds(saved);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateAiDescription = async () => {
    if (!formData.title || !formData.location) {
      alert("Please enter a title and location first so AI can contextualize the description.");
      return;
    }
    setIsAiLoading(true);
    setAiError(null);
    try {
      const details = `${formData.title} located in ${formData.location} with a target price of ${formData.price}`;
      const desc = await generatePropertyDescription(details);
      setFormData(prev => ({ ...prev, description: desc }));
    } catch (err: any) {
      console.error(err);
      setAiError(err.message || "AI failed to respond.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleToggleSave = async (id: string) => {
    const isSaved = savedIds.includes(id);
    try {
      await toggleSaveProperty(id, isSaved);
      setSavedIds(prev => isSaved ? prev.filter(p => p !== id) : [...prev, id]);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubmitListing = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await listProperty(formData);
      setShowModal(false);
      setFormData({ title: '', location: '', price: '', description: '', image_url: '' });
      fetchData();
    } catch (err) {
      alert("Error listing property. Please try again.");
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-slate-800">Property Hub</h2>
          <p className="text-slate-500">Discover and list exclusive listings across the city.</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all flex items-center gap-2"
        >
          <span>🏠</span> List New Property
        </button>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center p-20 gap-4">
          <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-slate-400 font-medium">Syncing listings...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {properties.length > 0 ? properties.map(property => (
            <div key={property.id} className="bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm hover:shadow-md transition-shadow group">
              <div className="aspect-[16/10] bg-slate-200 relative overflow-hidden">
                {property.image_url ? (
                  <img src={property.image_url} alt={property.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-4xl">🏙️</div>
                )}
                <button 
                  onClick={() => handleToggleSave(property.id)}
                  className={`absolute top-4 right-4 p-2 rounded-full shadow-lg transition-all ${
                    savedIds.includes(property.id) ? 'bg-pink-500 text-white' : 'bg-white text-slate-400 hover:text-pink-500'
                  }`}
                >
                  <svg className="w-5 h-5" fill={savedIds.includes(property.id) ? "currentColor" : "none"} stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                </button>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold text-slate-800 text-lg truncate">{property.title}</h4>
                  <span className="text-indigo-600 font-bold">{property.price}</span>
                </div>
                <p className="text-slate-500 text-sm mb-4 flex items-center gap-1">
                  <span>📍</span> {property.location}
                </p>
                <p className="text-slate-600 text-sm line-clamp-3 mb-4 h-15">{property.description}</p>
                <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Added {new Date(property.created_at).toLocaleDateString()}</span>
                  <button className="text-sm font-bold text-indigo-600 hover:underline">View Details</button>
                </div>
              </div>
            </div>
          )) : (
            <div className="col-span-full py-20 text-center bg-white rounded-3xl border border-dashed border-slate-300">
              <p className="text-slate-400 font-medium">No properties listed yet. Be the first!</p>
            </div>
          )}
        </div>
      )}

      {/* Listing Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-8 shadow-2xl relative animate-fadeIn">
            <button onClick={() => setShowModal(false)} className="absolute top-6 right-6 text-slate-400 hover:text-slate-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l18 18" />
              </svg>
            </button>
            
            <h3 className="text-2xl font-bold text-slate-800 mb-6">List Your Property</h3>
            
            <form onSubmit={handleSubmitListing} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-sm font-bold text-slate-600">Property Title</label>
                  <input required value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="w-full p-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500" placeholder="Cozy Downtown Apartment" />
                </div>
                <div className="space-y-1">
                  <label className="text-sm font-bold text-slate-600">Location</label>
                  <input required value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})} className="w-full p-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500" placeholder="New York, NY" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-sm font-bold text-slate-600">Price (USD/Month)</label>
                  <input required value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} className="w-full p-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500" placeholder="$2,500" />
                </div>
                <div className="space-y-1">
                  <label className="text-sm font-bold text-slate-600">Image URL</label>
                  <input value={formData.image_url} onChange={e => setFormData({...formData, image_url: e.target.value})} className="w-full p-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500" placeholder="https://..." />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-center mb-1">
                  <label className="text-sm font-bold text-slate-600">Description</label>
                  <button 
                    type="button"
                    onClick={handleGenerateAiDescription}
                    disabled={isAiLoading}
                    className={`text-xs font-bold flex items-center gap-1 hover:underline transition-colors ${aiError ? 'text-red-500' : 'text-indigo-600'}`}
                  >
                    {isAiLoading ? (
                      <span className="flex items-center gap-1 animate-pulse">
                        <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce"></div>
                        Gemini Thinking...
                      </span>
                    ) : aiError ? '⚠️ Try Again' : '✨ Generate with AI'}
                  </button>
                </div>
                <textarea 
                  required 
                  rows={4} 
                  value={formData.description} 
                  onChange={e => setFormData({...formData, description: e.target.value})} 
                  className={`w-full p-3 rounded-xl border outline-none focus:ring-2 focus:ring-indigo-500 resize-none transition-colors ${aiError ? 'border-red-200 bg-red-50' : 'border-slate-200'}`} 
                  placeholder={aiError ? `Error: ${aiError}` : "Tell us about the property..."} 
                />
              </div>

              <button type="submit" className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold shadow-lg hover:bg-indigo-700 transition-all mt-4">
                Submit Listing
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PropertyHub;
