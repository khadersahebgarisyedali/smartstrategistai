
export enum ViewType {
  ADVISOR = 'advisor',
  MARKETING = 'marketing',
  IMAGE_LAB = 'image_lab',
  DASHBOARD = 'dashboard',
  SUPPORT = 'support',
  PROPERTIES = 'properties',
  PROFILE = 'profile'
}

export interface Property {
  id: string;
  created_at: string;
  title: string;
  description: string;
  price: string;
  location: string;
  image_url: string;
  user_id: string;
}

export interface StrategyResult {
  title: string;
  content: string;
}

export interface MarketingContent {
  type: string;
  text: string;
}

export interface ImageResult {
  url: string;
  prompt: string;
}
